# Upstream source snapshot

This folder retains the complete upstream Capri Desktop source archive used as the reference for the Android adaptation. It includes the original desktop source tree and original assets, rather than only the subset copied into the Android app.

- Upstream project: https://github.com/lachydotmcg/capri-desktop
- Snapshot commit recorded in the archive: `72d6b8374905689d8d49736079f322c9429bd52e`
- The Android code is an unofficial, non-commercial adaptation and is not an official upstream release.
- Preserve the upstream license and attribution. See `CAPRI-LICENSE.md` and the original archive's `LICENSE.md`.

The source archive is retained for reference. Desktop C# / WinForms / Avalonia components are not automatically executable on Android and must be ported to Android APIs individually.
