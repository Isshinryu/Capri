package com.capri.mobile

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.View
import kotlin.math.max

/** Native renderer using the frame counts and timing from Capri Desktop's Pet.cs. */
class SpriteStripView(context: Context) : View(context) {
    private data class ClipSpec(val frames: Int, val fps: Long)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val handler = Handler(Looper.getMainLooper())
    private val specs = linkedMapOf(
        "idle" to ClipSpec(16, 8), "blink" to ClipSpec(4, 8), "blink_glitch" to ClipSpec(4, 8),
        "glitch" to ClipSpec(10, 15), "dangle" to ClipSpec(24, 10), "perch" to ClipSpec(16, 8),
        "perch_blink" to ClipSpec(4, 8), "perch_blink_glitch" to ClipSpec(4, 8),
        "perch_glitch" to ClipSpec(10, 15), "mouth" to ClipSpec(5, 12), "walk" to ClipSpec(12, 12),
        "dance" to ClipSpec(16, 16), "perch_dance" to ClipSpec(16, 16), "arrive" to ClipSpec(14, 15),
        "leave" to ClipSpec(12, 15), "perch_arrive" to ClipSpec(14, 15), "perch_leave" to ClipSpec(12, 15),
        "grin" to ClipSpec(16, 8), "sleep" to ClipSpec(16, 8), "wake" to ClipSpec(13, 8), "face" to ClipSpec(1, 1)
    )
    private val strips = mutableMapOf<String, Bitmap>()
    private var current = "idle"
    private var frame = 0
    private var frameCount = 16
    private var frameW = 240
    private var frameH = 384
    private var delay = 125L
    private val tick = object : Runnable {
        override fun run() {
            frame = (frame + 1) % max(1, frameCount)
            invalidate()
            handler.postDelayed(this, delay)
        }
    }

    init {
        specs.keys.forEach { name ->
            runCatching { BitmapFactory.decodeStream(context.assets.open("sprites/$name.png")) }
                .getOrNull()?.let { strips[name] = it }
        }
        select("idle")
        handler.postDelayed(tick, delay)
    }

    fun nextAnimation() {
        val names = listOf("idle", "blink", "grin", "glitch", "dance", "walk", "sleep", "wake", "arrive", "leave", "dangle", "mouth", "perch", "perch_arrive", "perch_blink", "perch_blink_glitch", "perch_dance", "perch_glitch", "perch_leave")
        val index = names.indexOf(current).let { if (it < 0) 0 else it }
        select(names[(index + 1) % names.size])
    }

    fun showAnimation(name: String) = select(name)

    private fun select(name: String) {
        current = if (strips.containsKey(name)) name else "idle"
        val bitmap = strips[current] ?: return
        val spec = specs[current] ?: ClipSpec(1, 8)
        frameCount = spec.frames.coerceAtLeast(1)
        frameW = max(1, bitmap.width / frameCount)
        frameH = bitmap.height
        delay = (1000L / spec.fps.coerceAtLeast(1)).coerceAtLeast(16L)
        frame = 0
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bitmap = strips[current] ?: return
        val source = Rect(frame * frameW, 0, (frame + 1) * frameW, frameH)
        val ratio = frameW.toFloat() / frameH.toFloat()
        val targetH = height.toFloat()
        val targetW = targetH * ratio
        val left = (width - targetW) / 2f
        val target = RectF(left, 0f, left + targetW, targetH)
        canvas.drawBitmap(bitmap, source, target, paint)
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(tick)
        super.onDetachedFromWindow()
    }
}
