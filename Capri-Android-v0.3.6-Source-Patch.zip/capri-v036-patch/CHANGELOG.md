# Capri Android v0.3.6 initial implementation batch

- Manual dragging now saves position and pins Capri at the point where she is dropped, instead of snapping to the bottom edge.
- Added best-effort visible-display-frame keyboard detection. Capri moves to the top-right while a keyboard appears and restores her prior coordinates when it closes. This requires physical-device testing across keyboard apps.
- The app's Dismiss action requests the original leave/perch-leave animation before removing the overlay.
- Long-press animation cycling now includes dance and perch-dance.
- Bumped Android versionCode to 7 and versionName to 0.3.6-companion-fixes.
- The original 39 upstream assets remain unchanged.

This is a first implementation batch, not the full audit roadmap. The original ElevenLabs settings flow, full desktop UI, face takeover behavior, complete animation state graph, and Android action dispatcher remain future work.
