plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.capri.mobile"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.capri.mobile"
        minSdk = 26
        targetSdk = 30
        versionCode = 2
        versionName = "0.2-prototype"
    }
}
