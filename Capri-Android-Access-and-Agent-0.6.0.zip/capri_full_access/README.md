# Capri Android Port — Source Port 0.3.5 (assets integrated)

An in-progress Android port of the original `lachydotmcg/capri-desktop` repository. This is not an official release and is not yet a complete desktop-equivalent port.

## This revision

- Mirrors the complete upstream `assets/` folder to `app/src/main/assets/` using the same relative paths: `capri.png`, `perch.png`, `sprites/`, `voice/`, `fonts/`, and `readme/`.
- Preserves every upstream asset byte-for-byte. `tools/verify_assets.py` verifies filename parity and SHA-256 equality against `upstream-source/assets/`.
- Uses the original `capri.png` in the app's landing screen and uses the bundled Share Tech Mono typeface for native UI text.
- Uses the original repository's cross-platform icon artwork for the Android launcher icon; it is resized only to the standard Android icon dimensions.
- The sprite renderer and greeting player read original files at their upstream relative paths (`sprites/*.png` and `voice/*.wav`), not from a duplicated `original/` subfolder.
- Keeps the original cross-platform icon, artwork, static perch illustration, font license, and readme reference images available in app assets so future ports can use them by their source paths.

## Asset inventory

There are 39 files in upstream `assets/` at reference commit `72d6b8374905689d8d49736079f322c9429bd52e`. The Android asset directory is an exact mirror. `face.png` remains a preserved original artwork asset; its desktop use in takeover effects is not yet ported to Android. Static `readme/` images are reference material, not frames in the live pet animation system.

Verify from this `android/` folder:

```sh
python tools/verify_assets.py
```

## Current Android implementation

- Native floating overlay and sprite-strip renderer using upstream animations.
- Basic drag interaction, autonomous horizontal movement, and Android-adapted resting/perch state.
- Playback of the original three time-based greeting WAVs.
- Android TTS output, speech-recognition input, local chat history, and configurable OpenAI-compatible chat endpoint.
- Original artwork, font, and official repository icon integrated into the app UI.

## Still incomplete

This is not a complete port. The desktop program includes richer screen/window-aware perching and movement, a full brain/agent/tool execution harness, voice provider discovery and management, music reactions, sound effects and lifecycle behavior, and desktop-specific computer interaction. Those features are not all implemented on Android. Android APIs and permission rules may require substitutes, and the app must not claim to access the screen or control other apps unless the relevant Android capability is implemented and granted.

## Build

Open this `android/` directory in Android Studio with Android SDK Platform 35 and a compatible Gradle setup. The project targets minSdk 26 and targetSdk 30, with compileSdk 35. The included workflow at `.github/workflows/android-build.yml` verifies assets before building. A successful compilation proves only that the project compiles, not that behavior matches the desktop app or works on every device.

## License

Upstream source: `upstream-source/`; original license: `CAPRI-LICENSE.md`. The upstream project is under the PolyForm Noncommercial License 1.0.0. Use and redistribution must comply with that license.

## Android access foundation (0.6.0 source pass)

This build adds permissioned Android access building blocks:

- Enable **Capri UI Access** from the app's button to let the accessibility service read exposed UI labels, click labels, fill matching editable fields, scroll, and send Back/Home gestures.
- Use **Start Screen Sharing** to invoke Android's MediaProjection consent dialog. A persistent notification appears while sharing is active and includes a Stop sharing action. Captured frames stay in process memory; this pass does not upload them or run OCR.
- Use **Choose a File**, **Choose a Folder**, and **Create a Text File** to grant Capri access only to items you select through Android's Storage Access Framework.
- Chat local commands include `read screen`, `my capabilities`, `list apps`, `open app <package.name>`, `start screen sharing`, `copy <text>`, `back`, `scroll down`, `scroll up`, and `type into <field label>: <text>`.

Android deliberately remains in control of permission grants. Accessibility cannot inspect secure surfaces or controls that apps do not expose. File access is scoped to user-selected URIs. Screen capture requires explicit approval every session. No root access, hidden monitoring, or permission bypass is included.

The source has not yet been built with a full Android SDK/Gradle environment or tested on a physical device. The next major engineering step is to connect `CapriAgentTools` to a true multi-step model tool-call loop, then add OCR/visual interpretation and verify every action on Android 11.

### Agent tool calling
The chat loop now advertises Android tools using OpenAI-compatible function schemas and supports up to five tool/model rounds in one turn. Capri can request capability status, read exposed screen text, list apps, interact with accessible controls, inspect a user-selected folder, or read a user-selected text file. Writes, coordinate taps, app launches, and other consequential actions are confirmation-gated. The user must clearly approve after Capri asks. Providers must support Chat Completions tool/function calling; providers without that feature may reject the request.

Selected file contents, folder names, accessible screen text, and requested screen images are returned to the model and therefore may be sent to the AI provider configured in Settings. Avoid selecting sensitive files unless you intend to share their contents with that provider.
