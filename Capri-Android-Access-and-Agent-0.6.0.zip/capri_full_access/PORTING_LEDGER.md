# Capri Android Porting Ledger

## Pass 0.5.0: Android permissioned access foundation
- [x] Accessibility service registration and user-enabled UI text/click/scroll bridge
- [x] App discovery and package launch helper
- [x] Clipboard write helper
- [x] Capability inventory

## Pass 0.6.0: Expanded access and tool execution
- [x] Explicit MediaProjection consent flow and foreground screen-capture service
- [x] Storage Access Framework file/folder selection
- [x] Persistable user-granted URI permissions
- [x] Bounded UTF-8 file reading and user-selected text writing helper
- [x] Selected-folder listing
- [x] Agent tool registry with structured result envelopes
- [x] Confirmation gates for consequential tool actions
- [x] Accessibility global Back/Home actions
- [x] Local chat commands wired to basic Android tools
- [ ] OCR/visual interpretation of captured frames
- [x] Multi-step LLM tool-call loop and tool-result continuation (bounded to five rounds)
- [ ] UI node targeting by view ID and editable-field text entry
- [ ] Full device validation on Android 11 hardware

## Security/platform boundaries
Android permissions remain user-controlled. No root, permission bypass, silent screen capture, arbitrary filesystem access, or hidden surveillance is implemented. Screen frames are not transmitted to an AI provider by this pass.
