package com.capri.mobile

import android.content.Context
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** Capability inventory and safe Android actions exposed to Capri's agent layer. */
object CapriAndroidCapabilities {
    fun inventory(context: Context): JSONObject = JSONObject().apply {
        put("platform", "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        put("accessibility", CapriAccessibilityService.isEnabled())
        put("overlay", Settings.canDrawOverlays(context))
        put("microphonePermission", context.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
        put("screenCapture", CapriScreenCaptureService.isRunning())
        put("screenCaptureConsentRequired", true)
        put("filePicker", "Android Storage Access Framework")
        put("agentTools", CapriAgentTools.definitions())
        put("files", "Storage Access Framework available; user selects files/folders")
        put("clipboardRead", "Foreground-app and Android-version restrictions apply")
        put("actions", JSONArray().put("read_visible_ui").put("click_visible_text").put("scroll").put("list_launchable_apps").put("launch_app").put("write_clipboard").put("open_accessibility_settings").put("open_overlay_settings").put("open_app_settings").put("screen_capture_with_consent").put("file_picker"))
    }

    fun readVisibleUi(): String = CapriAccessibilityService.visibleText()
    fun clickVisibleText(label: String): Boolean = CapriAccessibilityService.clickText(label)
    fun scroll(forward: Boolean): Boolean = CapriAccessibilityService.scroll(forward)

    fun launchableApps(context: Context): JSONArray {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val matches = if (Build.VERSION.SDK_INT >= 33) context.packageManager.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
            else @Suppress("DEPRECATION") context.packageManager.queryIntentActivities(intent, 0)
        return JSONArray().also { out -> matches.sortedBy { it.loadLabel(context.packageManager).toString().lowercase() }.forEach { info ->
            out.put(JSONObject().put("name", info.loadLabel(context.packageManager).toString()).put("package", info.activityInfo.packageName))
        } }
    }

    fun launchApp(context: Context, packageName: String): Boolean {
        if (packageName.isBlank()) return false
        val launch = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching { context.startActivity(launch); true }.getOrDefault(false)
    }

    fun writeClipboard(context: Context, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Capri", text))
    }

    fun openAccessibilitySettings(context: Context) = open(context, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    fun openOverlaySettings(context: Context) = open(context, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
    fun openAppSettings(context: Context) = open(context, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")))
    private fun open(context: Context, intent: Intent) { intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); runCatching { context.startActivity(intent) } }
}
