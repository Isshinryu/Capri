package com.capri.mobile

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.atomic.AtomicReference

/** User-enabled bridge to Android's visible UI. Android requires the user to enable it manually. */
class CapriAccessibilityService : AccessibilityService() {
    companion object {
        private val active = AtomicReference<CapriAccessibilityService?>(null)
        fun isEnabled(): Boolean = active.get() != null
        fun visibleText(): String = active.get()?.readVisibleText().orEmpty()
        fun clickText(label: String): Boolean = active.get()?.clickLabel(label) ?: false
        fun scroll(forward: Boolean): Boolean = active.get()?.scrollPage(forward) ?: false
        fun globalBack(): Boolean = active.get()?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) ?: false
        fun globalHome(): Boolean = active.get()?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) ?: false
        fun setText(label: String, value: String): Boolean = active.get()?.setNodeText(label, value) ?: false
        fun tap(x: Float, y: Float): Boolean = active.get()?.tapPoint(x, y) ?: false
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = (serviceInfo ?: AccessibilityServiceInfo()).apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = flags or AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 250
        }
        active.set(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit
    override fun onDestroy() { active.compareAndSet(this, null); super.onDestroy() }

    private fun readVisibleText(): String {
        val root = rootInActiveWindow ?: return ""
        val out = LinkedHashSet<String>()
        collect(root, out, 0)
        root.recycle()
        return out.take(180).joinToString("\n").take(12000)
    }

    private fun collect(node: AccessibilityNodeInfo, out: MutableSet<String>, depth: Int) {
        if (depth > 30 || out.size >= 180) return
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) out.add(text)
        if (desc.isNotEmpty()) out.add(desc)
        for (i in 0 until node.childCount) node.getChild(i)?.let { child -> collect(child, out, depth + 1); child.recycle() }
    }

    private fun clickLabel(label: String): Boolean {
        if (label.isBlank()) return false
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(label)
        val target = nodes.firstOrNull { it.isClickable && it.isEnabled } ?: nodes.firstOrNull { it.isEnabled }
        val result = target?.let { node ->
            var current: AccessibilityNodeInfo? = node
            var clicked = false
            while (current != null && !clicked) {
                clicked = current.isClickable && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                current = if (clicked) null else current.parent
            }
            clicked
        } ?: false
        nodes.forEach { it.recycle() }; root.recycle()
        return result
    }

    private fun setNodeText(label: String, value: String): Boolean {
        if (label.isBlank()) return false
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(label)
        val target = nodes.firstOrNull { it.isEditable && it.isEnabled }
        val result = target?.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, android.os.Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value) }) ?: false
        nodes.forEach { it.recycle() }; root.recycle()
        return result
    }

    private fun tapPoint(x: Float, y: Float): Boolean {
        if (x < 0 || y < 0) return false
        val path = android.graphics.Path().apply { moveTo(x, y) }
        val gesture = android.accessibilityservice.GestureDescription.Builder()
            .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 80)).build()
        return dispatchGesture(gesture, null, null)
    }

    private fun scrollPage(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        val result = root.performAction(action)
        root.recycle()
        return result
    }
}
