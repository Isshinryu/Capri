package com.capri.mobile

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import java.util.Calendar

/** Playback for the original greeting clips shipped in the upstream Capri repository. */
object CapriAudio {
    private var player: MediaPlayer? = null

    @Synchronized
    fun playGreeting(context: Context, force: Boolean = false) {
        if (!force && !CapriPrefs.greetingsEnabled(context)) return
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val clip = when {
            hour in 5..11 -> "hello-morning.wav"
            hour in 12..20 -> "hello-miss.wav"
            else -> "hello-late.wav"
        }
        playAsset(context, "voice/$clip")
    }

    @Synchronized
    fun playAsset(context: Context, assetPath: String) {
        stop()
        try {
            val afd = context.assets.openFd(assetPath)
            val next = MediaPlayer()
            next.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            next.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            next.setOnCompletionListener { synchronized(this) { if (player === it) player = null; it.release() } }
            next.setOnErrorListener { mp, _, _ -> synchronized(this) { if (player === mp) player = null; mp.release() }; true }
            player = next
            next.prepare()
            next.start()
        } catch (_: Exception) {
            player?.release()
            player = null
        }
    }

    @Synchronized
    fun stop() {
        val old = player
        player = null
        try { old?.stop() } catch (_: Exception) {}
        try { old?.release() } catch (_: Exception) {}
    }
}
