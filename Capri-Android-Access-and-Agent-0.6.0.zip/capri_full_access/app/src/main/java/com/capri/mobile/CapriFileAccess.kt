package com.capri.mobile

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.database.Cursor
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject

/** SAF-based file access. Android owns the picker and grants only user-selected URI access. */
object CapriFileAccess {
    const val REQUEST_OPEN_FILE = 7401
    const val REQUEST_OPEN_FOLDER = 7402
    const val REQUEST_SAVE_FILE = 7403

    fun chooseFile(activity: Activity, mime: String = "*/*") {
        activity.startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = mime
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }, REQUEST_OPEN_FILE)
    }
    fun chooseFolder(activity: Activity) {
        activity.startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), REQUEST_OPEN_FOLDER)
    }
    fun chooseSaveLocation(activity: Activity, mime: String, suggestedName: String) {
        activity.startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = mime; putExtra(Intent.EXTRA_TITLE, suggestedName)
        }, REQUEST_SAVE_FILE)
    }
    fun persist(activity: Activity, data: Intent?) {
        val uri = data?.data ?: return
        val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        runCatching { activity.contentResolver.takePersistableUriPermission(uri, flags) }
    }
    fun rememberFile(context: Context, uri: Uri) { context.getSharedPreferences("capri_file_access", Context.MODE_PRIVATE).edit().putString("selected_file", uri.toString()).apply() }
    fun rememberFolder(context: Context, uri: Uri) { context.getSharedPreferences("capri_file_access", Context.MODE_PRIVATE).edit().putString("selected_folder", uri.toString()).apply() }
    fun selectedFile(context: Context): Uri? = context.getSharedPreferences("capri_file_access", Context.MODE_PRIVATE).getString("selected_file", null)?.let(Uri::parse)
    fun selectedFolder(context: Context): Uri? = context.getSharedPreferences("capri_file_access", Context.MODE_PRIVATE).getString("selected_folder", null)?.let(Uri::parse)
    fun readSelectedText(context: Context, maxBytes: Int = 32_000): String {
        val uri = selectedFile(context) ?: error("Choose a file in Capri first.")
        val input = context.contentResolver.openInputStream(uri) ?: error("Selected file is no longer accessible.")
        return input.use { stream ->
            val output = java.io.ByteArrayOutputStream(); val buffer = ByteArray(8192)
            while (true) { val count = stream.read(buffer); if (count < 0) break; require(output.size() + count <= maxBytes) { "File exceeds the ${maxBytes}-byte text limit." }; output.write(buffer, 0, count) }
            output.toByteArray().toString(Charsets.UTF_8)
        }
    }
    fun writeSelectedText(context: Context, content: String) {
        val uri = selectedFile(context) ?: error("Choose a destination file in Capri first.")
        context.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) } ?: error("Selected destination is not writable.")
    }
    fun listSelectedFolder(context: Context): JSONArray {
        val uri = selectedFolder(context) ?: error("Choose a folder in Capri first.")
        val root = DocumentsContract.getTreeDocumentId(uri)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(uri, root)
        val out = JSONArray()
        context.contentResolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE), null, null, null)?.use { c ->
            var n = 0
            while (c.moveToNext() && n++ < 200) out.put(JSONObject().put("id", c.getString(0)).put("name", c.getString(1)).put("directory", c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR).put("size", if (c.isNull(3)) JSONObject.NULL else c.getLong(3)))
        }
        return out
    }

    fun displayName(activity: Activity, uri: Uri): String {
        var name = uri.lastPathSegment ?: "selected item"
        val c = activity.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        c?.use { if (it.moveToFirst()) name = it.getString(0) ?: name }
        return name
    }
    fun readText(activity: Activity, uri: Uri, maxBytes: Int = 1_000_000): String = activity.contentResolver.openInputStream(uri)?.use { input ->
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        while (true) { val count = input.read(buffer); if (count < 0) break; require(output.size() + count <= maxBytes) { "File is larger than the ${maxBytes}-byte text limit." }; output.write(buffer, 0, count) }
        output.toByteArray().toString(Charsets.UTF_8)
    } ?: error("Could not open selected file")
    fun writeText(activity: Activity, uri: Uri, content: String) {
        activity.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) }
            ?: error("Could not write selected file")
    }
    fun listChildren(activity: Activity, treeUri: Uri, limit: Int = 200): JSONArray {
        val root = DocumentsContract.getTreeDocumentId(treeUri)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, root)
        val out = JSONArray()
        activity.contentResolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE), null, null, null)?.use { c ->
            var n = 0
            while (c.moveToNext() && n++ < limit) out.put(JSONObject()
                .put("id", c.getString(0)).put("name", c.getString(1))
                .put("directory", c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR)
                .put("size", if (c.isNull(3)) JSONObject.NULL else c.getLong(3)))
        }
        return out
    }
}
