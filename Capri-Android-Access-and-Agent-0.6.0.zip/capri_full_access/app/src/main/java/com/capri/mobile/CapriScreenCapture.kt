package com.capri.mobile

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.app.Service
import android.os.IBinder
import android.os.Build
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.content.pm.ServiceInfo
import android.util.DisplayMetrics
import android.view.WindowManager
import java.util.concurrent.atomic.AtomicReference

/** Explicit user-consented screen capture. A new consent is required for each session. */
class CapriScreenCaptureActivity : Activity() {
    companion object { const val REQUEST_CAPTURE = 7501 }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION") startActivityForResult(mgr.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }
    @Deprecated("Android activity result API retained for minSdk compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE && resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, CapriScreenCaptureService::class.java).putExtra("resultCode", resultCode).putExtra("resultData", data))
        }
        finish()
    }
}

class CapriScreenCaptureService : Service() {
    companion object {
        private val latest = AtomicReference<Bitmap?>(null)
        @Volatile private var running = false
        fun isRunning() = running
        fun latestFrame(): Bitmap? = latest.get()?.copy(Bitmap.Config.ARGB_8888, false)
        fun latestFrameDataUrl(): String? {
            val source = latestFrame() ?: return null
            return try {
                val scale = minOf(1f, 960f / source.width.toFloat())
                val scaled = if (scale < 1f) Bitmap.createScaledBitmap(source, (source.width * scale).toInt().coerceAtLeast(1), (source.height * scale).toInt().coerceAtLeast(1), true) else source
                val bytes = java.io.ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, 62, bytes)
                if (scaled !== source) scaled.recycle()
                "data:image/jpeg;base64," + android.util.Base64.encodeToString(bytes.toByteArray(), android.util.Base64.NO_WRAP)
            } finally { source.recycle() }
        }
    }
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val stopIntent = Intent(this, CapriScreenCaptureService::class.java).setAction("com.capri.mobile.STOP_SCREEN_CAPTURE")
        val stopPending = PendingIntent.getService(this, 752, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val notification = Notification.Builder(this, "capri-screen").setContentTitle("Capri screen access")
            .setContentText("Screen sharing is active. Stop it whenever you like.")
            .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop sharing", stopPending).build()).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(751, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(751, notification)
        if (intent?.action == "com.capri.mobile.STOP_SCREEN_CAPTURE") { stopCapture(); return START_NOT_STICKY }
        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("resultData", Intent::class.java) else @Suppress("DEPRECATION") (intent?.getParcelableExtra("resultData") as? Intent)
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION") (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels; val height = metrics.heightPixels; val density = metrics.densityDpi
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes[0]; val buffer = plane.buffer
                val pixelStride = plane.pixelStride; val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width
                val full = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
                full.copyPixelsFromBuffer(buffer)
                val cropped = Bitmap.createBitmap(full, 0, 0, width, height)
                latest.getAndSet(cropped)?.recycle(); full.recycle()
            } finally { image.close() }
        }, android.os.Handler(mainLooper))
        running = true
        projection?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopCapture() } }, android.os.Handler(mainLooper))
        display = projection?.createVirtualDisplay("CapriScreen", width, height, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null)
        return START_NOT_STICKY
    }
    private fun createChannel() { if (Build.VERSION.SDK_INT >= 26) (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel("capri-screen", "Capri screen sharing", NotificationManager.IMPORTANCE_LOW)) }
    private fun stopCapture() {
        if (!running && projection == null) { stopForeground(true); stopSelf(); return }
        running = false
        display?.release(); display = null
        reader?.close(); reader = null
        val activeProjection = projection; projection = null
        activeProjection?.stop()
        stopForeground(true); stopSelf()
    }
    override fun onDestroy() { running = false; display?.release(); reader?.close(); projection?.stop(); latest.getAndSet(null)?.recycle(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
