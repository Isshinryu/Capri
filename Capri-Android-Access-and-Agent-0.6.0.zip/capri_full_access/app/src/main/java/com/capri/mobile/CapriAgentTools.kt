package com.capri.mobile

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** Single registry/dispatcher for Android-native tools. Unknown tools fail closed. */
object CapriAgentTools {
    fun definitions(): JSONArray = JSONArray().apply {
        fun schema(name: String, description: String, properties: JSONObject = JSONObject(), required: JSONArray = JSONArray()) {
            put(JSONObject().put("type", "function").put("function", JSONObject()
                .put("name", name).put("description", description)
                .put("parameters", JSONObject().put("type", "object").put("properties", properties).put("required", required).put("additionalProperties", false))))
        }
        fun stringProp(key: String, description: String) = JSONObject().put(key, JSONObject().put("type", "string").put("description", description))
        schema("capabilities", "Report currently available Android capabilities")
        schema("screen_read_text", "Read text exposed by the active app's accessibility tree")
        schema("screen_capture_status", "Check whether user-approved screen capture is active")
        schema("screen_get_frame", "Get the latest frame from the user's actively approved screen-sharing session for visual understanding. Requires screen sharing to be active.")
        schema("files_read_selected", "Read the selected text file. File contents will be sent to the configured AI provider; requires user confirmation.")
        schema("files_list_selected_folder", "List names and metadata in the user-selected folder. This information is sent to the configured AI provider; requires user confirmation.")
        schema("files_write_selected", "Replace the contents of the selected file. Requires explicit user confirmation.", JSONObject().put("text", stringProp("text", "New file contents")), JSONArray().put("text"))
        schema("apps_list", "List launchable applications")
        schema("apps_launch", "Launch an installed app by package name. Requires user confirmation.", JSONObject().put("package", stringProp("package", "Android package name")), JSONArray().put("package"))
        schema("ui_click_text", "Tap a visible accessible label", JSONObject().put("text", stringProp("text", "Visible label")), JSONArray().put("text"))
        schema("ui_set_text", "Enter text into an accessible editable field matched by its current label", JSONObject().put("label", stringProp("label", "Current field label")).put("value", stringProp("value", "Text to enter")), JSONArray().put("label").put("value"))
        schema("ui_tap", "Tap screen coordinates. Only use when coordinates are known from a user-approved screen view.", JSONObject().put("x", JSONObject().put("type", "number")).put("y", JSONObject().put("type", "number")), JSONArray().put("x").put("y"))
        schema("ui_scroll", "Scroll the active screen", JSONObject().put("forward", JSONObject().put("type", "boolean")))
        schema("ui_back", "Navigate back in the active app")
        schema("ui_home", "Return to Android home screen. Requires user confirmation.")
        schema("clipboard_write", "Copy text to Android clipboard. Requires user confirmation.", JSONObject().put("text", stringProp("text", "Text to copy")), JSONArray().put("text"))
        schema("settings_accessibility", "Open Android accessibility settings")
        schema("settings_overlay", "Open Android display-over-other-apps settings")
    }

    /** Returns structured results. Actions with external or irreversible effects require confirmed=true. */
    fun execute(context: Context, name: String, args: JSONObject = JSONObject(), confirmed: Boolean = false): JSONObject {
        fun result(ok: Boolean, value: Any? = null, error: String? = null) = JSONObject().put("ok", ok).put("result", value ?: JSONObject.NULL).put("error", error ?: JSONObject.NULL)
        return try {
            when (name) {
                "capabilities" -> result(true, CapriAndroidCapabilities.inventory(context))
                "screen_read_text" -> result(CapriAccessibilityService.isEnabled(), CapriAndroidCapabilities.readVisibleUi(), if (!CapriAccessibilityService.isEnabled()) "Enable Capri UI Access in Android settings." else null)
                "screen_capture_status" -> result(true, JSONObject().put("active", CapriScreenCaptureService.isRunning()).put("note", "Screen images are not uploaded automatically."))
                "screen_get_frame" -> result(false, error = "Screen frames must be attached as an image by the chat agent, not returned as text.")
                "files_read_selected" -> { if (!confirmed) result(false, error = "Confirmation required. The selected file's text will be sent to your configured AI provider.") else result(true, CapriFileAccess.readSelectedText(context).take(16000)) }
                "files_list_selected_folder" -> { if (!confirmed) result(false, error = "Confirmation required before sending selected folder names to your AI provider.") else result(true, CapriFileAccess.listSelectedFolder(context)) }
                "files_write_selected" -> { if (!confirmed) result(false, error = "Confirmation required before overwriting the selected file.") else { CapriFileAccess.writeSelectedText(context, args.optString("text")); result(true) } }
                "apps_list" -> result(true, CapriAndroidCapabilities.launchableApps(context))
                "apps_launch" -> { if (!confirmed) result(false, error = "Confirmation required before launching an app.") else result(CapriAndroidCapabilities.launchApp(context, args.optString("package"))) }
                "ui_click_text" -> {
                    val label = args.optString("text")
                    val sensitive = label.contains(Regex("(?i)\\b(delete|remove|erase|purchase|buy|pay|send|submit|transfer|publish|confirm)\\b"))
                    if (sensitive && !confirmed) result(false, error = "Confirmation required before activating '$label'.")
                    else result(CapriAndroidCapabilities.clickVisibleText(label))
                }
                "ui_set_text" -> result(CapriAccessibilityService.setText(args.optString("label"), args.optString("value")))
                "ui_tap" -> { if (!confirmed) result(false, error = "Confirmation required before tapping arbitrary screen coordinates.") else result(CapriAccessibilityService.tap(args.optDouble("x", -1.0).toFloat(), args.optDouble("y", -1.0).toFloat())) }
                "ui_scroll" -> result(CapriAndroidCapabilities.scroll(args.optBoolean("forward", true)))
                "ui_back" -> result(CapriAccessibilityService.globalBack())
                "ui_home" -> { if (!confirmed) result(false, error = "Confirmation required before leaving the current app.") else result(CapriAccessibilityService.globalHome()) }
                "clipboard_write" -> { if (!confirmed) result(false, error = "Confirmation required before changing the clipboard.") else { CapriAndroidCapabilities.writeClipboard(context, args.optString("text")); result(true) } }
                "settings_accessibility" -> { CapriAndroidCapabilities.openAccessibilitySettings(context); result(true) }
                "settings_overlay" -> { CapriAndroidCapabilities.openOverlaySettings(context); result(true) }
                else -> result(false, error = "Unknown tool: $name")
            }
        } catch (e: Exception) { result(false, error = e.message ?: "Tool failed") }
    }
}
