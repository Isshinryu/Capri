# Capri Android Port Status — 0.6.0 source pass

## Reference source
- Repository: `lachydotmcg/capri-desktop`
- Reference commit: `72d6b8374905689d8d49736079f322c9429bd52e`
- Full upstream snapshot: `upstream-source/`
- Exact upstream asset mirror: `app/src/main/assets/`
- Verification script: `tools/verify_assets.py`
- SHA-256 list: `UPSTREAM-ASSET-SHA256.txt`

## Integrated asset usage
- All 39 files from upstream `assets/` are copied byte-for-byte at their original relative asset paths.
- Runtime sprites load from `sprites/`; original greeting audio loads from `voice/`.
- Landing screen displays upstream `capri.png`.
- UI uses upstream `fonts/ShareTechMono-Regular.ttf`.
- Launcher artwork is sourced from upstream `cross/icon.png`.
- `perch.png`, `chip.png`, `chip-source.png`, `chip.ico`, all `readme/` previews, and the font license remain packaged at their corresponding upstream asset paths.
- `sprites/face.png` is retained exactly. Its desktop role in takeover effects is not yet implemented on Android; static reference images are also not live animations.

## Implemented in Android source
- Sprite-strip renderer with explicit source-derived clip counts and frame rates, idle/perch blink substitutions, glitch clips, breathing/sway, sleep/wake, speech mouth overlay, and interaction states.
- Basic overlay dragging, horizontal wandering, and a simplified screen-edge resting state.
- Original time-based greeting WAV playback and preview/stop controls.
- Native Android TTS replies, Android speech recognition input, compatible AI chat endpoint, local history, personality/memory settings.
- Original asset paths and text typeface wired into app UI.

## Still incomplete
- Complete desktop window-aware movement, cursor interaction, seat detection and perching on arbitrary windows.
- Original brain/agent/tool harness and full execution semantics.
- Original external voice-provider discovery/configuration, complete voice pack flow, and all sound/music reactions.
- Desktop-only screen understanding and system control replaced with Android equivalents only where permissioned APIs are available. These features are not all ported.
- Physical-device rendering/behavior checks and pixel comparisons remain outstanding.

## Verification
Run `python tools/verify_assets.py` from this `android/` directory. The Android build workflow runs the same check before compiling. This source package has not been device-tested as a consequence of creating the package; do not infer runtime correctness from archive or build success alone.

### Android access foundation update (2026-11-01)
A first capability bridge is now present in source: user-enabled accessibility service (visible text extraction, label-based click, page scroll), app discovery/launch, clipboard write, and access inventory/settings shortcuts. This is not unrestricted device control. Screen capture still needs MediaProjection consent; files need Storage Access Framework user selection; clipboard reads and background access remain Android-restricted. No full Gradle build/device test has been performed yet.

### Expanded Android capability pass (2026-11-01)
- Added a single Android agent tool registry/dispatcher with structured results and confirmation gates for app launch, leaving the current app, and clipboard modification.
- Added explicit MediaProjection consent activity and foreground capture service. Captured frames remain on-device until Capri explicitly requests a frame through the agent; then a scaled JPEG may be sent to the configured AI provider for visual interpretation. Capture is session-based and must be approved by the user.
- Added Storage Access Framework helpers for selecting files/folders, persisting URI grants, listing a selected folder, reading bounded UTF-8 text, and writing text to a user-selected destination.
- Expanded accessibility bridge with global Back/Home actions. UI interaction remains limited to controls exposed by apps' accessibility trees.
- Added local chat commands for screen text, capability status, launchable app listing/launch, screen-share consent, clipboard copy, Back, and scrolling.
- Added landing-screen entry points for screen-sharing consent and user-selected file/folder access.
- These are foundations, not full autonomous parity: no OCR engine, recursive background filesystem crawling, arbitrary shell/root access, universal touch coordinates, automatic screen upload, or unrestricted background control. App launching/file writes/clipboard actions are still constrained by Android and explicit consent.


## Verification for 0.6.0 source pass
- XML parsing: AndroidManifest.xml and accessibility-service XML passed.
- Asset verification: all 39 mirrored upstream assets passed exact path and SHA-256 checks.
- ZIP integrity: verified after packaging.
- Full Gradle/Android compilation: not run because this recovered source package does not include a Gradle wrapper and no Android SDK platform is installed in this work environment. A plain Kotlin compiler check cannot type-check Android APIs without android.jar.
- Device test: not run. MediaProjection, accessibility gestures, SAF providers, and Android 11 OEM behavior still require physical-device verification.
- Added an optional visual-frame tool that attaches a scaled JPEG from the active, user-approved screen-sharing session to a multimodal model request. Vision support depends on the configured provider/model.
- Added OpenAI-compatible function/tool-call continuation to the chat request loop (up to five model/tool rounds per user turn). Tool definitions use JSON Schema; tool outputs are returned to the model before it generates its final reply.
- Added confirmation-aware tool execution. Destructive-looking UI labels, coordinate taps, app launch, home navigation, clipboard writes, selected-file reads/writes, and folder listing are gated; a clear affirmative response is only accepted after Capri's previous reply asked for confirmation/approval/permission.
- The user-selected file and folder URIs are remembered with persistable Android grants. The agent can read a bounded selected text file, list the selected folder, and overwrite a selected destination only after confirmation. File text/folder metadata may be sent to the configured AI provider when used as tool results.
