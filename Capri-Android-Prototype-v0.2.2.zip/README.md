# Capri Android Port — Prototype 0.2.2

This is an evolving native Android port scaffold based on the uploaded Capri Desktop source. It is not an official Capri release.

## Added in 0.2
- Native floating companion overlay using the original sprite strips from the upstream project.
- Chat screen backed by an OpenAI-compatible `/v1/chat/completions` endpoint.
- Configurable API endpoint, model ID, and API key.
- Editable Capri personality and user memory notes, stored locally.
- Persistent local conversation history (last 20 messages are sent as context).
- Android speech recognition input and Android Text-to-Speech replies.
- Chat and settings buttons in the main screen; tapping the floating character opens chat.
- Full original sprite collection and original voice sample assets copied from the source.

## Not yet ported
Capri's original C# `Brain`, `Engine`, `Hands`, and `Voice` components are not automatically portable to Android. The current AI chat is a separate mobile implementation using a compatible web API. Native offline inference, ElevenLabs integration, contextual screen understanding, Android accessibility actions, media/app automation, richer animation state machine, and voice-cloning/voice packs remain future work.

## Build
Open this folder in Android Studio, install Android SDK Platform 35, allow Gradle sync, then use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The project uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21. It targets API 30 for the initial Android 11 focus; test newer Android versions because overlay and foreground-service rules differ.

A build has not been verified in this environment because an Android SDK and Gradle executable are not installed here. This ZIP is source code, not an APK.

## First launch
1. Open **AI / Voice / Memory Settings**.
2. Enter an OpenAI-compatible chat-completions URL, model ID, and API key from a provider you trust.
3. Adjust Capri's personality and long-term memory notes if desired.
4. Open chat and send a message. Android speech recognition and system TTS depend on speech services installed on the device.
5. Grant **Display over other apps** permission to summon the floating companion.

API usage may cost money depending on the provider. Your key is stored in app-private SharedPreferences, not encrypted with a dedicated key vault. Do not use a key with privileges you cannot risk exposing. Chat and memory are stored locally on the device.

## Source and license
The upstream Capri project is distributed under PolyForm Noncommercial 1.0.0. See `CAPRI-LICENSE.md`. This modified port is for non-commercial use unless the upstream rights holder grants other permission. Original assets are retained; do not remove the license notice.

## Optional cloud build
A GitHub Actions workflow is included at `.github/workflows/android-build.yml`. If you put this project in a GitHub repository and enable Actions, run **Build Capri Android APK** from the Actions tab. When it finishes successfully, download the `capri-mobile-debug-apk` artifact. This workflow has been added but has not been run from this environment, so it is not yet a verified build.
\n\n## Build compatibility fix (0.2.2)\nJava and Kotlin compilation both target JVM 17 to avoid inconsistent JVM-target compatibility errors.\n