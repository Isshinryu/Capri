package com.capri.mobile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.FrameLayout

class CompanionService : Service() {
    private lateinit var windowManager: WindowManager
    private var companion: FrameLayout? = null
    private var sprite: SpriteStripView? = null
    private var startX = 0; private var startY = 0
    private var touchX = 0f; private var touchY = 0f
    private var moved = false
    private var downAt = 0L
    override fun onCreate() {
        super.onCreate(); startForeground(41, notification())
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = (152 * resources.displayMetrics.density).toInt()
        sprite = SpriteStripView(this)
        companion = FrameLayout(this).apply { addView(sprite, FrameLayout.LayoutParams(-1, -1)) }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(size, size, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 12; y = 180 }
        companion?.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; touchX = event.rawX; touchY = event.rawY; moved = false; downAt = event.eventTime; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - touchX; val dy = event.rawY - touchY
                    if (dx * dx + dy * dy > 64) moved = true
                    params.x = startX + dx.toInt(); params.y = startY + dy.toInt()
                    runCatching { windowManager.updateViewLayout(view, params) }; true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = event.rawX - touchX; val dy = event.rawY - touchY
                    if (!moved && dx * dx + dy * dy < 100) { if (event.eventTime - downAt >= 550L) sprite?.nextAnimation() else openChat() }
                    true
                }
                else -> false
            }
        }
        runCatching { windowManager.addView(companion, params) }.onFailure { stopSelf() }
    }
    private fun openChat() {
        val intent = Intent(this, ChatActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        startActivity(intent)
    }
    private fun notification(): Notification {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) manager.createNotificationChannel(NotificationChannel("capri_companion", "Capri companion", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0))
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, "capri_companion").setContentTitle("Capri is here").setContentText("Tap Capri to chat, or open the app to manage her.").setSmallIcon(android.R.drawable.ic_dialog_info).setContentIntent(open).setOngoing(true).build()
        else @Suppress("DEPRECATION") Notification.Builder(this).setContentTitle("Capri is here").setContentText("Tap Capri to chat.").setSmallIcon(android.R.drawable.ic_dialog_info).setContentIntent(open).setOngoing(true).build()
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onDestroy() { companion?.let { runCatching { windowManager.removeView(it) } }; companion = null; sprite = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
