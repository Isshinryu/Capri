package com.capri.mobile

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.view.View
import android.os.Handler
import android.os.Looper
import kotlin.math.max

class SpriteStripView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val handler = Handler(Looper.getMainLooper())
    private val names = listOf("idle", "blink", "grin", "glitch", "dance", "walk", "sleep", "wake", "arrive", "leave", "dangle", "mouth", "perch", "perch_arrive", "perch_blink", "perch_blink_glitch", "perch_dance", "perch_glitch", "perch_leave", "face")
    private val strips = mutableMapOf<String, Bitmap>()
    private var current = "idle"
    private var frame = 0
    private var frames = 1
    private var frameW = 384
    private var frameH = 384
    private val tick = object : Runnable {
        override fun run() {
            frame = (frame + 1) % max(1, frames)
            invalidate()
            handler.postDelayed(this, 85L)
        }
    }

    init {
        names.forEach { name ->
            runCatching { BitmapFactory.decodeStream(context.assets.open("sprites/$name.png")) }
                .getOrNull()?.let { strips[name] = it }
        }
        select("idle")
        handler.postDelayed(tick, 85L)
    }

    fun nextAnimation() {
        val index = names.indexOf(current).let { if (it < 0) 0 else it }
        select(names[(index + 1) % names.size])
    }

    private fun select(name: String) {
        current = if (strips.containsKey(name)) name else "idle"
        val bitmap = strips[current] ?: return
        frameH = bitmap.height
        frameW = if (bitmap.width >= bitmap.height) bitmap.height else bitmap.width
        frames = max(1, bitmap.width / frameW)
        frame = 0
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bitmap = strips[current] ?: return
        val source = Rect(frame * frameW, 0, (frame + 1) * frameW, frameH)
        val target = Rect(0, 0, width, height)
        canvas.drawBitmap(bitmap, source, target, paint)
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(tick)
        super.onDetachedFromWindow()
    }
}
